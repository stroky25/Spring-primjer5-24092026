package hr.java.vjezbe.hardwareapp.dto;

import hr.java.vjezbe.hardwareapp.domain.Hardware;
import hr.java.vjezbe.hardwareapp.domain.Type;
import jakarta.validation.constraints.*;

import java.math.BigDecimal;

public class HardwareDTO {

    @NotBlank(message = "Name must not be empty")
    @Size(max = 200, message = "Name can't have more than 200 characters")
    private String name;

    @NotNull(message = "Type must be set to CPU, GPU, MBO, RAM, STORAGE or OTHER")
    private Type type;

    @NotBlank(message = "Code must not be empty")
    @Size(min = 7, max = 7, message = "Code must have 7 characters")
    private String code;

    @PositiveOrZero(message = "Stock must be positive or zero")
    @Max(value = 10000, message = "Stock can't be above 10000")
    private long stock;

    @PositiveOrZero(message = "Price must be positive or zero")
    @Digits(integer = 5, fraction = 2, message = "Price can't be higher than 99999")
    private BigDecimal price;

    public HardwareDTO() {}

    public HardwareDTO(String name, Type type, String code, long stock, BigDecimal price) {
        this.name = name;
        this.type = type;
        this.code = code;
        this.stock = stock;
        this.price = price;
    }

    public HardwareDTO(Hardware hardware) {
        this.name = hardware.getName();
        this.price = hardware.getPrice();
        this.code = hardware.getCode();
        this.stock = hardware.getStock();
        this.type = hardware.getType();
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public Type getType() { return type; }
    public void setType(Type type) { this.type = type; }
    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
    public long getStock() { return stock; }
    public void setStock(long stock) { this.stock = stock; }
    public BigDecimal getPrice() { return price; }
    public void setPrice(BigDecimal price) { this.price = price; }

    @Override
    public String toString() {
        return "HardwareDTO{" +
                "name='" + name + '\'' +
                ", type=" + type +
                ", code='" + code + '\'' +
                ", stock=" + stock +
                ", price=" + price +
                '}';
    }
}
