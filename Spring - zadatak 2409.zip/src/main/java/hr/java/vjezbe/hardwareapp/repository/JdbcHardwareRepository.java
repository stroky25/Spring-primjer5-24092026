package hr.java.vjezbe.hardwareapp.repository;

import hr.java.vjezbe.hardwareapp.domain.Hardware;
import hr.java.vjezbe.hardwareapp.domain.Type;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.LinkedHashSet;
import java.util.Optional;
import java.util.Set;

@Repository
@Primary
public class JdbcHardwareRepository implements HardwareRepository {

    private final JdbcTemplate jdbcTemplate;

    public JdbcHardwareRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private Hardware mapRow(java.sql.ResultSet rs, int rowNum) throws java.sql.SQLException {
        return new Hardware(
                rs.getLong("id"),
                rs.getString("name"),
                Type.valueOf(rs.getString("type")),
                rs.getString("code"),
                rs.getLong("stock"),
                rs.getBigDecimal("price")
        );
    }

    @Override
    public Set<Hardware> findAll() {
        return new LinkedHashSet<>(jdbcTemplate.query(
                "SELECT id, name, type, code, stock, price FROM hardware ORDER BY id",
                this::mapRow
        ));
    }

    @Override
    public Optional<Hardware> findByCode(String code) {
        return jdbcTemplate.query(
                "SELECT id, name, type, code, stock, price FROM hardware WHERE code = ?",
                this::mapRow,
                code
        ).stream().findFirst();
    }

    @Override
    public Optional<Hardware> save(Hardware hardware) {
        if (findByCode(hardware.getCode()).isPresent()) {
            return Optional.empty();
        }

        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(
                    "INSERT INTO hardware (name, type, code, stock, price) VALUES (?, ?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS
            );
            ps.setString(1, hardware.getName());
            ps.setString(2, hardware.getType().name());
            ps.setString(3, hardware.getCode());
            ps.setLong(4, hardware.getStock());
            ps.setBigDecimal(5, hardware.getPrice());
            return ps;
        }, keyHolder);

        return Optional.of(new Hardware(
                keyHolder.getKey().longValue(),
                hardware.getName(), hardware.getType(), hardware.getCode(),
                hardware.getStock(), hardware.getPrice()
        ));
    }

    @Override
    public Optional<Hardware> update(String code, Hardware updatedHardware) {
        if (findByCode(code).isEmpty()) {
            return Optional.empty();
        }

        jdbcTemplate.update(
                "UPDATE hardware SET name = ?, type = ?, code = ?, stock = ?, price = ? WHERE code = ?",
                updatedHardware.getName(), updatedHardware.getType().name(), updatedHardware.getCode(),
                updatedHardware.getStock(), updatedHardware.getPrice(), code
        );

        return findByCode(updatedHardware.getCode());
    }

    @Override
    public void deleteByCode(String code) {
        jdbcTemplate.update("DELETE FROM hardware WHERE code = ?", code);
    }
}
