package hr.java.vjezbe.hardwareapp.domain;

public enum Type {
    CPU, GPU, MBO, RAM, STORAGE, OTHER
}
