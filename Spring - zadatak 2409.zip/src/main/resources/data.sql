INSERT INTO hardware (name, type, code, stock, price) VALUES
('Asus TUF RTX 3080', 'GPU', '1234561', 0, 1599.00),
('EVGA XC3 RTX 3070 Ti', 'GPU', '1234562', 0, 1299.00),
('AMD Ryzen 5950X', 'CPU', '1234563', 0, 899.00),
('Samsung 980 PRO SSD 1TB', 'STORAGE', '1234564', 0, 299.00),
('Kingston FURY Beast DDR5 32GB', 'RAM', '1234565', 0, 699.00);
